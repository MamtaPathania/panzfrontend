import React from 'react'

function PopUp() {
  return (
    <div className='flex justify-center items-center bg-black lg:h-[80px] h-[50px] '>
    <img src={Img} alt="toonflix" className='lg:h-[50px] lg:w-[190px] h-[30px] m-6 text-center'/>
  
</div>
  )
}

export default PopUp
